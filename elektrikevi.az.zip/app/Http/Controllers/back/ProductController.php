<?php

namespace App\Http\Controllers\back;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Domains;
use App\Models\Feature;
use App\Models\Product;
use App\Models\ProductPhoto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use File;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products=Product::orderBy('name')->with('status')->get();
        $crumbs=[
            'Məhsul'=>route('admin.product'),
        ];
        $title='Məhsul listi';
        return view('back.product.index',compact('products','crumbs','title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $crumbs=[
            'Məhsul'=>route('admin.product'),
            'Yeni'=>route('admin.product.create')
        ];
        $title='Yeni Məhsul';

        $cateqories=Category::where('parent_id',0)->get();

        return view('back.product.create',compact('crumbs','title','cateqories'));
    }


    public function getChildCategory()
    {
        $parentId=request('parentId');
        $cateqories=Category::where('parent_id',$parentId)->get();

        return view('back.render.get-child-category',compact('cateqories'))->render();

    }

    public function getChildCategoryWithSelected()
    {
        $categoryItem= json_decode(request('item'));
        $parentId=request('val');
        $cateqories=Category::where('parent_id',$parentId)->get();

        return view('back.render.get-child-category-with-selected',compact('cateqories','categoryItem'))->render();

    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'name'=>'required',
            'price'=>'required',
            'stock_count'=>'required',
            'description'=>'required',
        ]);


        DB::transaction(function () {
            $data=[
                'name'=>request('name'),
                'price'=>request('price'),
                'stock_count'=>request('stock_count'),
                'description'=>request('description'),
                'code'=>'P-'.rand(100,999).Str::random(2),
                'is_active'=>1,
                'status_id'=>1,
                'domain'=>Category::find(request('parent_id'))->domain
            ];
            $data['slug'] = Str::slug(request('name'));
            if (Product::whereSlug($data['slug'])->count() > 0) {

                return back()
                    ->withInput()
                    ->withErrors(['slug' => 'Bazada bu adda məhsul vardır']);

            }


            if (request('discount') == 1) {
                $this->validate(request(), [
                    'interest' => 'required',
                    'discount_date' => 'required'
                ]);

                $data['discount'] = 1;
                $data['interest'] = request('interest');

                $data['discount_price'] = request('price')- (request('price') * request('interest')) / 100;
                $data['discount_date'] = request('discount_date');
            }


            $product = Product::create($data);

            $childId=request('child_id');
            $parentId=request('parent_id');

            if(is_array($childId)) {
                array_push($childId,$parentId);
            } else {
                $childId=[];
                array_push($childId,$parentId);

            }
            $product->category()->attach($childId);


            for ($i=0;$i<count(request('title'));$i++) {
                if(request('title')[$i]!=null and request('content')[$i]!=null) {
                    $product->feature()->create([
                        'title'=>request('title')[$i],
                        'content'=>request('content')[$i]
                    ]);
                }
            }




            if (request()->hasFile('photos')) {
                $photos = request()->file('photos');

                foreach ($photos as $photo) {
                    if ($photo->isValid()) {
                        $file_name = $product->id . '-' . rand(0, 999) . time() . '.' . $photo->extension();
                        $photo->move('uploads/product', $file_name);

                        ProductPhoto::create(
                            ['product_id' => $product->id,
                                'photo' => $file_name,
                                'parent' => 0,
                                'child' => 0
                            ]
                        );
                    }
                }
            } else {
                $product->update([
                    'status_id' => 2,
                    'is_active' => 0
                ]);
            }

        });

        return redirect()
            ->route('admin.product.create')
            ->with('type','success')
            ->with('mesaj','Yeni məhsul əlavə edildi');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function edit($slug)
    {
        $categoryItem=[];
        $product=Product::with('category','feature')->with('photo')->whereSlug($slug)->firstOrFail();

        foreach ($product->category as $category) {
            array_push($categoryItem,$category->id);
        }

        $crumbs=[
            'Məhsul'=>route('admin.product'),
            $product->name=>route('admin.product.edit',$slug)
        ];
        $title='Məhsulun yenilənməsi';
        $cateqories=Category::where('parent_id',0)->get();
       // dd($categoryItem);
        return view('back.product.edit',compact('crumbs','title','cateqories','product','categoryItem'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $slug)
    {
        $this->validate($request,[
            'name'=>'required',
            'price'=>'required',
            'stock_count'=>'required',
            'description'=>'required',
        ]);

        $product=Product::with('photo')->where('slug',$slug)->first();
        $data=[
            'name'=>request('name'),
            'price'=>request('price'),
            'stock_count'=>request('stock_count'),
            'description'=>request('description'),
            'code'=>'P-'.rand(100,999).Str::random(2),
            'is_active'=>1,
            'status_id'=>1
        ];
        $slug=Str::slug(request('name'));
        $product->slug = $slug;
        $product->name=request('name');
        $product->price=request('price');
        $product->stock_count=request('stock_count');
        $product->description=request('description');
        $product->is_active=1;
        $product->status_id=1;
        $product->domain=Category::find(request('parent_id'))->domain;


        if (request('discount') == 1) {
            $this->validate(request(), [
                'interest' => 'required',
                'discount_date' => 'required'
            ]);

            $product->discount = 1;
            $product->interest = request('interest');

            $product->discount_price = request('price')- (request('price') * request('interest')) / 100;
            $product->discount_date = request('discount_date');
        }

        $childId=request('child_id');
        $parentId=request('parent_id');

        if(is_array($childId)) {
            array_push($childId,$parentId);
        } else {
            $childId=[];
            array_push($childId,$parentId);

        }

        $product->save();
        $product->category()->sync($childId);
        $product->feature()->delete();
        if(is_array(request('title'))) {
            for ($i=0;$i<count(request('title'));$i++) {
                if(request('title')[$i]!=null and request('content')[$i]!=null) {
                    $product->feature()->updateOrCreate([
                        'title'=>request('title')[$i],
                        'content'=>request('content')[$i]
                    ]);

                }
            }

        }

        if (request()->hasFile('photos')) {
            $photos = request()->file('photos');
            foreach ($product->photo as $key) {
                $last_image_path = public_path("/uploads/product/$key->photo");
                if(File::exists($last_image_path)) {
                    File::delete($last_image_path);
                }
            }
            foreach ($photos as $photo) {
                if ($photo->isValid()) {
                    $file_name = $product->id . '-' . rand(0, 999) . time() . '.' . $photo->extension();
                    $photo->move('uploads/product', $file_name);

                    ProductPhoto::create(
                        ['product_id' => $product->id,
                            'photo' => $file_name,
                            'parent' => 0,
                            'child' => 0
                        ]
                    );
                }
            }


        }

        $countProductPhoto=$product->photo()->count();

        if($countProductPhoto<2) {
            $product->update([
                'status_id' => 2,
                'is_active' => 0
            ]);
        }


        return redirect()
            ->route('admin.product.edit',$product->slug)
            ->with('type','success')
            ->with('mesaj','Dəyişikliklər yerinə yetirildi');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($slug)
    {
        $product=Product::with('photo')->where('slug',$slug)->first();
        foreach ($product->photo as $key) {
            $last_image_path = public_path("/uploads/product/$key->photo");
            if(File::exists($last_image_path)) {
                File::delete($last_image_path);
            }
        }

        $product->delete();

        return redirect()
            ->route('admin.product')
            ->with('type','success')
            ->with('mesaj','Silinmə tamamlandı');

    }

    public function removeOnePhoto($id,$slug)
    {
        $product=Product::with('photo')->where('slug',$slug)->first();

        $photo=ProductPhoto::find($id);
        $last_image_path = public_path("/uploads/product/$photo->photo");
        if(File::exists($last_image_path)) {
            File::delete($last_image_path);
        }
        $photo->delete();
        $countProductPhoto=$product->photo()->count();

        if($countProductPhoto<2) {
            $product->update([
                'status_id' => 2,
                'is_active' => 0
            ]);
        }

        return redirect()
            ->route('admin.product.edit',$slug)
            ->with('type','success')
            ->with('mesaj','Şəkil silindi');

    }

    public function updateOnePhoto()
    {
        $this->validate(request(), [
            'id' => 'required',
            'slug' => 'required'
        ]);
        $id=request('id');
        $slug=request('slug');


        $product=Product::with('photo')->where('slug',$slug)->first();

        if (request()->hasFile('photos')) {
            $photos = request()->file('photos');

            foreach ($photos as $photo) {
                if ($photo->isValid()) {
                    $file_name = $product->id . '-' . rand(0, 999) . time() . '.' . $photo->extension();
                    $photo->move('uploads/product', $file_name);

                    ProductPhoto::create(
                        ['product_id' => $product->id,
                            'photo' => $file_name,
                            'parent' => 0,
                            'child' => 0
                        ]
                    );
                }
            }
        }

        $photo=ProductPhoto::find($id);


        $last_image_path = public_path("/uploads/product/$photo->photo");
        if(File::exists($last_image_path)) {
            File::delete($last_image_path);
        }
        $photo->delete();


        $countProductPhoto=$product->photo()->count();

        if($countProductPhoto<2) {
            $product->update([
                'status_id' => 2,
                'is_active' => 0
            ]);
        }

        return redirect()
            ->route('admin.product.edit',$slug)
            ->with('type','success')
            ->with('mesaj','Şəkil yeniləndi');
    }


    public function addParentPhoto()
    {
        $id=request('id');
        $slug=request('slug');
        $product=Product::with('photo')->where('slug',$slug)->first();
        $product->photo()->update([
            'parent'=>0
        ]);

        $photo=ProductPhoto::find($id);
        $photo->parent=1;
        $photo->save();
    }

    public function removeParentPhoto()
    {
        $id=request('id');

        $photo=ProductPhoto::find($id);
        $photo->parent=0;
        $photo->save();
    }


    public function addChildPhoto()
    {
        $id=request('id');
        $slug=request('slug');
        $product=Product::with('photo')->where('slug',$slug)->first();
        $product->photo()->update([
            'child'=>0
        ]);

        $photo=ProductPhoto::find($id);
        $photo->child=1;
        $photo->save();
    }

    public function removeChildPhoto()
    {
        $id=request('id');

        $photo=ProductPhoto::find($id);
        $photo->child=0;
        $photo->save();
    }
}