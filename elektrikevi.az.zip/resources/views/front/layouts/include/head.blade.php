<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>{{config('app.name')}} & @yield('title')</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Favicon -->
<link rel="icon" href="{{asset('uploads/logo/icon.png')}}">

<!--=============================================
=            CSS  files       =
=============================================-->

<!-- Vendor CSS -->
<link href="/front/assets/css/vendors.css" rel="stylesheet">
<!-- Main CSS -->
<link href="/front/assets/css/style.css" rel="stylesheet">
<script src="/front/assets/js/sweetalert.js"></script>