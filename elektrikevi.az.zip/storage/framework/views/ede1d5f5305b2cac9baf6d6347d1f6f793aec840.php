
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('head'); ?>

    <!-- Theme JS files -->
    <script type="text/javascript" src="/back/assets/js/plugins/tables/datatables/datatables.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/plugins/tables/datatables/extensions/responsive.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/plugins/forms/selects/select2.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/pages/datatables_responsive.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <?php echo $__env->make('back.layouts.include.page-header',compact('crumbs'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('back.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="panel panel-flat">
        <div class="panel-heading">
            <h5 class="panel-title"><?php echo e($title); ?></h5>
            <div class="heading-elements">
            </div>
        </div>

        <table class="table datatable-responsive-row-control">
            <thead>
            <tr>
                <th></th>
                <th>Sifarişçi</th>
                <th>Email</th>
                <th>Mobil</th>
                <th>Şəhər</th>
                <th>Rayon</th>
                <th>Küçə</th>
                <th>Poçt İndeksi</th>
                <th>Ünvan</th>
                <th>Bank</th>
                <th>Tutar(ƏDV ilə)</th>
                <th>Tutar(ƏDV siz)</th>
                <th>ƏDV Miqdarı</th>
                <th>Status</th>
                <th>Sifariş Tarixi
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php if($orders->count()>0): ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td><a href="mailto:<?php echo e($order->email); ?>"><?php echo e($order->fullname); ?></a></td>
                        <td><a href="mailto:<?php echo e($order->email); ?>"><?php echo e($order->email); ?></a></td>
                        <td><a href="tel:<?php echo e($order->mobil); ?>"><?php echo e($order->mobil); ?></a></td>
                        <td><?php echo e($order->city->name); ?></td>
                        <td><?php echo e($order->region->name); ?></td>
                        <td><?php echo e($order->street->name); ?></td>
                        <td><?php echo e($order->zip_code); ?></td>
                        <td><?php echo e($order->adress); ?></td>
                        <td><?php echo e($order->bank); ?></td>
                        <td><?php echo e($order->order_total); ?></td>
                        <td><?php echo e($order->sub_total); ?></td>
                        <td><?php echo e($order->edv_total); ?></td>
                        <td>
                            <select  class="form-control">
                                <?php if($status->count()>0): ?>
                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key->id); ?>" <?php echo e($order->status_id==$key->id ? 'selected' : ''); ?>><?php echo e($key->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </td>
                        <td><?php echo e($order->order_created_at_no_pm()); ?></td>
                        <td>
                            <a class="label label-info" href="<?php echo e(route('admin.order.show',$order->basket_id)); ?>"> <i class="icon-basket"></i> Məhsulları</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/back/order/index.blade.php ENDPATH**/ ?>