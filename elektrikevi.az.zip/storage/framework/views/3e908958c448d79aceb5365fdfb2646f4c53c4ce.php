
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('front.layouts.include.header-two',['desktopCategory'=>$desktopCategory,'mobileCategory'=>$mobileCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('front.layouts.include.breadcrumb',compact('crumbs','title'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="page-content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!--=======  page wrapper  =======-->
                    <div class="page-wrapper">
                        <div class="page-content-wrapper">
                            <?php echo $__env->make('front.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php if(count($newCompareProducts)>0): ?>
                                <form action="#">

                                    <!-- Compare Table -->
                                    <div class="compare-table table-responsive">
                                        <table class="table mb-0">
                                            <tbody>
                                            <tr>
                                                <td class="first-column">Ad</td>
                                                <?php if(isset($newCompareProducts[0]['id'])): ?>
                                                    <td class="product-image-title">
                                                        <a href="<?php echo e(route('product.detail',$newCompareProducts[0]['slug'])); ?>" class="image"><img src="<?php echo e(asset("uploads/product").'/'.$newCompareProducts[0]['photo']); ?>" class="img-fluid" alt="<?php echo e($newCompareProducts[0]['name']); ?>"></a>
                                                        <a href="<?php echo e(route('product.detail',$newCompareProducts[0]['slug'])); ?>" class="title"><?php echo e($newCompareProducts[0]['name']); ?></a>
                                                    </td>
                                                <?php endif; ?>
                                                <?php if(isset($newCompareProducts[1]['id'])): ?>
                                                    <td class="product-image-title">
                                                        <a href="<?php echo e(route('product.detail',$newCompareProducts[1]['slug'])); ?>" class="image"><img src="<?php echo e(asset("uploads/product").'/'.$newCompareProducts[1]['photo']); ?>" class="img-fluid" alt="<?php echo e($newCompareProducts[1]['name']); ?>"></a>
                                                        <a href="<?php echo e(route('product.detail',$newCompareProducts[1]['slug'])); ?>" class="title"><?php echo e($newCompareProducts[1]['name']); ?></a>
                                                    </td>
                                                <?php endif; ?>
                                                <?php if(isset($newCompareProducts[2]['id'])): ?>
                                                    <td class="product-image-title">
                                                        <a href="<?php echo e(route('product.detail',$newCompareProducts[2]['slug'])); ?>" class="image"><img src="<?php echo e(asset("uploads/product").'/'.$newCompareProducts[2]['photo']); ?>" class="img-fluid" alt="<?php echo e($newCompareProducts[2]['name']); ?>"></a>
                                                        <a href="<?php echo e(route('product.detail',$newCompareProducts[2]['slug'])); ?>" class="title"><?php echo e($newCompareProducts[2]['name']); ?></a>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                            <tr>
                                                <td class="first-column">Təsvir</td>
                                                <?php if(isset($newCompareProducts[0]['id'])): ?>
                                                    <td class="pro-desc">
                                                        <p><?php echo e($newCompareProducts[0]['description']); ?></p>
                                                    </td>
                                                <?php endif; ?>
                                                <?php if(isset($newCompareProducts[1]['id'])): ?>
                                                    <td class="pro-desc">
                                                        <p><?php echo e($newCompareProducts[1]['description']); ?></p>
                                                    </td>
                                                <?php endif; ?>
                                                <?php if(isset($newCompareProducts[2]['id'])): ?>
                                                    <td class="pro-desc">
                                                        <p><?php echo e($newCompareProducts[2]['description']); ?></p>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                            <tr>
                                                <td class="first-column">Qiymət</td>
                                                <?php if(isset($newCompareProducts[0]['id'])): ?>
                                                    <td class="pro-price">$<?php echo e($newCompareProducts[0]['price']); ?></td>
                                                <?php endif; ?>
                                                <?php if(isset($newCompareProducts[1]['id'])): ?>
                                                    <td class="pro-price">$<?php echo e($newCompareProducts[1]['price']); ?></td>
                                                <?php endif; ?>
                                                <?php if(isset($newCompareProducts[2]['id'])): ?>
                                                    <td class="pro-price">$<?php echo e($newCompareProducts[2]['price']); ?></td>
                                                <?php endif; ?>
                                            </tr>
                                            <tr>
                                                <td class="first-column">Stok</td>
                                                <?php if(isset($newCompareProducts[0]['id'])): ?>
                                                    <td class="pro-stock"><?php echo e($newCompareProducts[0]['stock_count']>0 ? 'Vardır' : 'Yoxdur'); ?></td>
                                                <?php endif; ?>
                                                <?php if(isset($newCompareProducts[1]['id'])): ?>
                                                    <td class="pro-stock"><?php echo e($newCompareProducts[1]['stock_count']>0 ? 'Vardır' : 'Yoxdur'); ?></td>
                                                <?php endif; ?>
                                                <?php if(isset($newCompareProducts[2]['id'])): ?>
                                                    <td class="pro-stock"><?php echo e($newCompareProducts[2]['stock_count']>0 ? 'Vardır' : 'Yoxdur'); ?></td>
                                                <?php endif; ?>
                                            </tr>
                                            <tr>
                                                <td class="first-column">Add to cart</td>
                                                <?php if(isset($newCompareProducts[0]['id'])): ?>
                                                    <td class="pro-addtocart">
                                                        <?php if(in_array($newCompareProducts[0]['id'],$basketItem)): ?>
                                                            <a class="add-to-cart" href="<?php echo e(route('removeFromCartById',$newCompareProducts[0]['id'])); ?>">
                                                                <i class="ion-minus fa-2x"></i>
                                                            </a>
                                                        <?php else: ?>
                                                            <a class="add-to-cart" href="<?php echo e(route('addToCartById',$newCompareProducts[0]['id'])); ?>">
                                                                <i class="ion-plus fa-2x"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endif; ?>
                                                <?php if(isset($newCompareProducts[1]['id'])): ?>
                                                    <td class="pro-addtocart">
                                                        <?php if(in_array($newCompareProducts[1]['id'],$basketItem)): ?>
                                                            <a class="add-to-cart" href="<?php echo e(route('removeFromCartById',$newCompareProducts[1]['id'])); ?>">
                                                                <i class="ion-minus fa-2x"></i>
                                                            </a>
                                                        <?php else: ?>
                                                            <a class="add-to-cart" href="<?php echo e(route('addToCartById',$newCompareProducts[1]['id'])); ?>">
                                                                <i class="ion-plus fa-2x"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endif; ?>
                                                <?php if(isset($newCompareProducts[2]['id'])): ?>
                                                    <td class="pro-addtocart">
                                                        <?php if(in_array($newCompareProducts[2]['id'],$basketItem)): ?>
                                                            <a class="add-to-cart" href="<?php echo e(route('removeFromCartById',$newCompareProducts[2]['id'])); ?>">
                                                                <i class="ion-minus fa-2x"></i>
                                                            </a>
                                                        <?php else: ?>
                                                            <a class="add-to-cart"name=""  href="<?php echo e(route('addToCartById',$newCompareProducts[2]['id'])); ?>">
                                                                <i class="ion-plus fa-2x"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                            <tr>
                                                <td class="first-column">Sil</td>
                                                <?php if(isset($newCompareProducts[0]['id'])): ?>
                                                    <td class="pro-remove"><a href="<?php echo e(route('removeFromCompareById',$newCompareProducts[0]['id'])); ?>"><i class="fa fa-trash-o"></i></a></td>
                                                <?php endif; ?>
                                                <?php if(isset($newCompareProducts[1]['id'])): ?>
                                                    <td class="pro-remove"><a href="<?php echo e(route('removeFromCompareById',$newCompareProducts[1]['id'])); ?>"><i class="fa fa-trash-o"></i></a></td>
                                                <?php endif; ?>
                                                <?php if(isset($newCompareProducts[2]['id'])): ?>
                                                    <td class="pro-remove"><a href="<?php echo e(route('removeFromCompareById',$newCompareProducts[2]['id'])); ?>"><i class="fa fa-trash-o"></i></a></td>
                                                <?php endif; ?>
                                            </tr>

                                            </tbody>
                                        </table>
                                    </div>

                                </form>
                            <?php else: ?>
                                <div class="alert alert-info" role="alert">
                                    Müqayisə ediləcək məhsul yoxdur!
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!--=======  End of page wrapper  =======-->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/front/compare.blade.php ENDPATH**/ ?>