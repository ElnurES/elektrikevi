<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <style>
        *{ font-family: DejaVu Sans !important;}
    </style>

</head>
<body>
<div class="page-content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">

                
                <div class="page-wrapper">
                    <div class="page-content-wrapper">
                        <!-- Header -->
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#e1e1e1">
                            <tr>
                                <td height="20"></td>
                            </tr>
                            <tr>
                                <td>
                                    <table width="600" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#ffffff" style="border-radius: 10px 10px 0 0;">
                                        <tr class="hiddenMobile">
                                            <td height="40"></td>
                                        </tr>
                                        <tr class="visibleMobile">
                                            <td height="30"></td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <table width="480" border="0" cellpadding="0" cellspacing="0" align="center" class="fullPadding">
                                                    <tbody>
                                                    <tr>
                                                        <td>
                                                            <table width="220" border="0" cellpadding="0" cellspacing="0" align="left" class="col">
                                                                <tbody>
                                                                <tr>
                                                                    <td align="left"> <img src="http://www.supah.it/dribbble/017/logo.png" width="32" height="32" alt="logo" border="0" /></td>
                                                                </tr>
                                                                <tr class="hiddenMobile">
                                                                    <td height="40"></td>
                                                                </tr>
                                                                <tr class="visibleMobile">
                                                                    <td height="20"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 12px; color: #5b5b5b; font-family: 'Open Sans', sans-serif; line-height: 18px; vertical-align: top; text-align: left;">
                                                                        Salam, <?php echo e($order->fullname); ?>.
                                                                        <br> Mağazamızdan alış-veriş etdiyinizə və sifarişinizə görə təşəkkür edirik.
                                                                    </td>
                                                                </tr>
                                                                </tbody>
                                                            </table>
                                                            <table width="220" border="0" cellpadding="0" cellspacing="0" align="right" class="col">
                                                                <tbody>
                                                                <tr class="visibleMobile">
                                                                    <td height="20"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="5"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 21px; color: #ff0000; letter-spacing: -1px; font-family: 'Open Sans', sans-serif; line-height: 1; vertical-align: top; text-align: right;">
                                                                        Hesab-faktura
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                <tr class="hiddenMobile">
                                                                    <td height="50"></td>
                                                                </tr>
                                                                <tr class="visibleMobile">
                                                                    <td height="20"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 12px; color: #5b5b5b; font-family: 'Open Sans', sans-serif; line-height: 18px; vertical-align: top; text-align: right;">
                                                                        <small>SİFARİŞ</small> #<?php echo e($order->id); ?><br />
                                                                        <small><?php echo e($order->order_created_at_no_pm()); ?></small>
                                                                    </td>
                                                                </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                        <!-- /Header -->
                        <!-- Order Details -->
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#e1e1e1">
                            <tbody>
                            <tr>
                                <td>
                                    <table width="600" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#ffffff">
                                        <tbody>
                                        <tr>
                                        <tr class="hiddenMobile">
                                            <td height="60"></td>
                                        </tr>
                                        <tr class="visibleMobile">
                                            <td height="40"></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <table width="480" border="0" cellpadding="0" cellspacing="0" align="center" class="fullPadding">
                                                    <tbody>
                                                    <tr>
                                                        <th style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #5b5b5b; font-weight: normal; line-height: 1; vertical-align: top; padding: 0 10px 7px 0;" width="52%" align="left">
                                                            Ad
                                                        </th>
                                                        <th style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #5b5b5b; font-weight: normal; line-height: 1; vertical-align: top; padding: 0 0 7px;" align="left">
                                                            <small>Alış qiyməti</small>
                                                        </th>
                                                        <th style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #5b5b5b; font-weight: normal; line-height: 1; vertical-align: top; padding: 0 0 7px;" align="center">
                                                            Ədəd
                                                        </th>
                                                        <th style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #1e2b33; font-weight: normal; line-height: 1; vertical-align: top; padding: 0 0 7px;" align="right">
                                                            Cəmi
                                                        </th>
                                                    </tr>
                                                    <tr>
                                                        <td height="1" style="background: #bebebe;" colspan="4"></td>
                                                    </tr>
                                                    <tr>
                                                        <td height="10" colspan="4"></td>
                                                    </tr>
                                                    <?php $__currentLoopData = $order->basket->basket_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #ff0000;  line-height: 18px;  vertical-align: top; padding:10px 0;" class="article">
                                                                <?php echo e($basket->product->name); ?>

                                                            </td>
                                                            <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #646a6e;  line-height: 18px;  vertical-align: top; padding:10px 0;"><small><?php echo e($basket->price); ?></small></td>
                                                            <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #646a6e;  line-height: 18px;  vertical-align: top; padding:10px 0;" align="center"><?php echo e($basket->count); ?></td>
                                                            <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #1e2b33;  line-height: 18px;  vertical-align: top; padding:10px 0;" align="right">$<?php echo e($basket->count*$basket->price); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td height="1" colspan="4" style="border-bottom:1px solid #e4e4e4"></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="20"></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <!-- /Order Details -->
                        <!-- Total -->
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#e1e1e1">
                            <tbody>
                            <tr>
                                <td>
                                    <table width="600" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#ffffff">
                                        <tbody>
                                        <tr>
                                            <td>

                                                <!-- Table Total -->
                                                <table width="480" border="0" cellpadding="0" cellspacing="0" align="center" class="fullPadding">
                                                    <tbody>
                                                    <tr>
                                                        <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #646a6e; line-height: 22px; vertical-align: top; text-align:right; ">
                                                            Cəmi
                                                        </td>
                                                        <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #646a6e; line-height: 22px; vertical-align: top; text-align:right; white-space:nowrap;" width="80">
                                                            $<?php echo e($order->sub_total); ?>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #646a6e; line-height: 22px; vertical-align: top; text-align:right; ">
                                                            Ünvan çatdırılma
                                                        </td>
                                                        <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #646a6e; line-height: 22px; vertical-align: top; text-align:right; ">
                                                            $00.00
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #000; line-height: 22px; vertical-align: top; text-align:right; ">
                                                            <strong>Cəmi (Ədv ilə)</strong>
                                                        </td>
                                                        <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #000; line-height: 22px; vertical-align: top; text-align:right; ">
                                                            <strong>$<?php echo e($order->order_total); ?></strong>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #b0b0b0; line-height: 22px; vertical-align: top; text-align:right; "><small>ƏDV</small></td>
                                                        <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #b0b0b0; line-height: 22px; vertical-align: top; text-align:right; ">
                                                            <small>$<?php echo e($order->order_total-$order->sub_total); ?></small>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                                <!-- /Table Total -->

                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <!-- /Total -->
                        <!-- Information -->
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#e1e1e1">
                            <tbody>
                            <tr>
                                <td>
                                    <table width="600" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#ffffff">
                                        <tbody>
                                        <tr>
                                        <tr class="hiddenMobile">
                                            <td height="60"></td>
                                        </tr>
                                        <tr class="visibleMobile">
                                            <td height="40"></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <table width="480" border="0" cellpadding="0" cellspacing="0" align="center" class="fullPadding">
                                                    <tbody>
                                                    <tr>
                                                        <td>
                                                            <table width="220" border="0" cellpadding="0" cellspacing="0" align="left" class="col">

                                                                <tbody>
                                                                <tr>
                                                                    <td style="font-size: 11px; font-family: 'Open Sans', sans-serif; color: #5b5b5b; line-height: 1; vertical-align: top; ">
                                                                        <strong>ÖDƏMƏ MƏLUMATI</strong>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="100%" height="10"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #5b5b5b; line-height: 20px; vertical-align: top; ">
                                                                        Nağd şəkildə
                                                                    </td>
                                                                </tr>
                                                                </tbody>
                                                            </table>


                                                            <table width="220" border="0" cellpadding="0" cellspacing="0" align="right" class="col">
                                                                <tbody>
                                                                <tr class="visibleMobile">
                                                                    <td height="20"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 11px; font-family: 'Open Sans', sans-serif; color: #5b5b5b; line-height: 1; vertical-align: top; ">
                                                                        <strong>Ödəniş Növü</strong>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="100%" height="10"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #5b5b5b; line-height: 20px; vertical-align: top; ">
                                                                        Çatdırılma Zamanı Nağd Ödəniş
                                                                    </td>
                                                                </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <table width="480" border="0" cellpadding="0" cellspacing="0" align="center" class="fullPadding">
                                                    <tbody>
                                                    <tr>
                                                        <td>
                                                            <table width="220" border="0" cellpadding="0" cellspacing="0" align="left" class="col">
                                                                <tbody>
                                                                <tr class="hiddenMobile">
                                                                    <td height="35"></td>
                                                                </tr>
                                                                <tr class="visibleMobile">
                                                                    <td height="20"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 11px; font-family: 'Open Sans', sans-serif; color: #5b5b5b; line-height: 1; vertical-align: top; ">
                                                                        <strong>Çatdırılma Məlumatları</strong>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="100%" height="10"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #5b5b5b; line-height: 20px; vertical-align: top; ">
                                                                        <?php echo e($order->city->name); ?><br> <?php echo $order->region->name!='' ? $order->region->name.' <br>' : ''; ?>

                                                                        <?php echo e($order->adress); ?><br><?php echo e($order->street->name); ?><br>  T: <?php echo e($order->mobil); ?><br>  E-pcçt: <?php echo e($order->email); ?>

                                                                        <br>  Poçt indeks: <?php echo e($order->zip_code); ?>

                                                                    </td>
                                                                </tr>
                                                                </tbody>
                                                            </table>


                                                            <table width="220" border="0" cellpadding="0" cellspacing="0" align="right" class="col">
                                                                <tbody>
                                                                <tr class="hiddenMobile">
                                                                    <td height="35"></td>
                                                                </tr>
                                                                <tr class="visibleMobile">
                                                                    <td height="20"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 11px; font-family: 'Open Sans', sans-serif; color: #5b5b5b; line-height: 1; vertical-align: top; ">
                                                                        <strong>Ödəniş Növü</strong>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="100%" height="10"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-size: 12px; font-family: 'Open Sans', sans-serif; color: #5b5b5b; line-height: 20px; vertical-align: top; ">
                                                                        Çatdırılma Zamanı Nağd Ödəniş
                                                                    </td>
                                                                </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr class="hiddenMobile">
                                            <td height="60"></td>
                                        </tr>
                                        <tr class="visibleMobile">
                                            <td height="30"></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <!-- /Information -->
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#e1e1e1">

                            <tr>
                                <td>
                                    <table width="600" border="0" cellpadding="0" cellspacing="0" align="center" class="fullTable" bgcolor="#ffffff" style="border-radius: 0 0 10px 10px;">
                                        <tr>
                                            <td>
                                                <table width="480" border="0" cellpadding="0" cellspacing="0" align="center" class="fullPadding">
                                                    <tbody>
                                                    <tr>
                                                        <td style="font-size: 12px; color: #5b5b5b; font-family: 'Open Sans', sans-serif; line-height: 18px; vertical-align: top; text-align: left;">
                                                            Hörmətlə,<br>
                                                            <?php echo e(config('app.name')); ?>

                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr class="spacer">
                                            <td height="50"></td>
                                        </tr>

                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td height="20"></td>
                            </tr>
                        </table>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/front/pdf/user-invoice.blade.php ENDPATH**/ ?>