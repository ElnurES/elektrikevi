
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('head'); ?>

    <!-- Theme JS files -->
    <script type="text/javascript" src="/back/assets/js/plugins/tables/datatables/datatables.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/plugins/tables/datatables/extensions/responsive.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/plugins/forms/selects/select2.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/pages/datatables_responsive.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <?php echo $__env->make('back.layouts.include.page-header',compact('crumbs'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('back.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="panel panel-flat">
        <div class="panel-heading">
            <h5 class="panel-title"><?php echo e($title); ?></h5>
        </div>

        <table class="table datatable-responsive-row-control">
            <thead>
            <tr>
                <th></th>
                <th>AdSoyad</th>
                <th>Email</th>
                <th>Message</th>
                <th>Cavabla</th>
                <th>Göndərilmə Tarixi</th>
                <th class="text-center"></th>
            </tr>
            </thead>
            <tbody>
            <?php if($contacts->count()>0): ?>
                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td><a href="mailto:<?php echo e($contact->email); ?>"><?php echo e($contact->fullname); ?></a></td>
                        <td><a href="mailto:<?php echo e($contact->email); ?>"><?php echo e($contact->email); ?></a></td>
                        <td><?php echo e($contact->message); ?></td>
                        <td><a href="mailto:<?php echo e($contact->email); ?>" class="label label-info"><i class="fa fa-pencil"></i> Cavab Yaz</a></td>
                        <td><?php echo e($contact->contact_created_at()); ?></td>
                        <td class="text-center">
                            <a style="color:red;" onclick='checkDeleteConfrim("<?php echo e(route('admin.contact.destroy',$contact->id)); ?>")'><i class="fa fa-trash"></i> Sil</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
    <script>
        function checkDeleteConfrim(url) {
            swal({
                title: "Silmək istədiynizdən əminsizmi?",
                text: "Silinəndən sonra bu əməliyyatı bərpa edə bilməyəcəksiniz!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
                .then((willDelete) => {
                    if (willDelete) {
                        location.href = url;
                    } else {
                        swal("Heç bir əməliyyat aparılmadı");
                    }
                });


        }
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/back/contact.blade.php ENDPATH**/ ?>