<div class="breadcrumb-area section-space--half">
    <div class="container wide">
        <div class="row">
            <div class="col-lg-12">

                <!--=======  breadcrumb wrpapper  =======-->
                <div class="breadcrumb-wrapper breadcrumb-bg" style="background-image: url(<?php echo e((isset($bImage) and !is_null($bImage)) ? $bImage : '/uploads/banner/s10.jpg'); ?>);">
                    <!--=======  breadcrumb content  =======-->
                    <div class="breadcrumb-content">

                        <h2 class="breadcrumb-content__title"><?php echo e($title); ?></h2>


                        <ul class="breadcrumb-content__page-map">
                            <li><a href="<?php echo e(route('home')); ?>">Əsas Səhifə</a></li>

                            <?php if(count($crumbs)>0): ?>
                                <?php $__currentLoopData = $crumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$crumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!$loop->last): ?>
                                        <li><a href="<?php echo e($crumb); ?>"><?php echo e($key); ?></a></li>
                                        <?php else: ?>
                                            <li class="active"><?php echo e($key); ?></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </ul>
                    </div>
                    <!--=======  End of breadcrumb content  =======-->
                </div>
                <!--=======  End of breadcrumb wrpapper  =======-->
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\HP\Desktop\kabel\resources\views/front/layouts/include/breadcrumb.blade.php ENDPATH**/ ?>