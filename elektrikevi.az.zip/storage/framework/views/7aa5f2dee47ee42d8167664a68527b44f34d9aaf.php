<div class="navbar navbar-default header-highlight">
    <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo e(route('admin')); ?>"><img src="/back/assets/images/logo_light.png" alt=""></a>

        <ul class="nav navbar-nav visible-xs-block">
            <li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
            <li><a class="sidebar-mobile-main-toggle"><i class="icon-paragraph-justify3"></i></a></li>
        </ul>
    </div>

    <div class="navbar-collapse collapse" id="navbar-mobile">
        <ul class="nav navbar-nav">
            <li><a class="sidebar-control sidebar-main-toggle hidden-xs"><i class="icon-paragraph-justify3"></i></a></li>

        </ul>


        <div class="navbar-right">
            <ul class="nav navbar-nav">
                <li class="dropdown dropdown-user">
                    <a class="dropdown-toggle" data-toggle="dropdown">
                        <img src="/back/assets/images/placeholder.jpg" alt="">
                        <span><?php echo e(auth()->guard('admin')->user()->fullname); ?></span>
                        <i class="caret"></i>
                    </a>

                    <ul class="dropdown-menu dropdown-menu-right">
                        <li><a href="<?php echo e(route('admin')); ?>"><i class="fa fa-home"></i> <span>Əsas Səhifə</span></a></li>
                        <li><a href="<?php echo e(route('admin.category')); ?>"><i class="fa fa-bars"></i> <span>Kategoriya</span></a></li>
                        <li><a href="<?php echo e(route('admin.product')); ?>"><i class="fa fa-shopping-basket"></i> <span>Məhsul</span></a></li>
                        <li><a href="<?php echo e(route('admin.order')); ?>"><i class="fa fa-shopping-cart"></i> <span>Sifariş</span></a></li>
                        <li><a href="<?php echo e(route('admin.user')); ?>"><i class="fa fa-users"></i> <span>İstifadəçilər</span></a></li>
                        <li><a href="<?php echo e(route('admin.config')); ?>"><i class="fa fa-cogs"></i> <span>Parametrlər</span></a></li>
                        <li><a href="<?php echo e(route('admin.contact')); ?>"><i class="fa fa-phone-square"></i> <span>Əlaqə</span></a></li>
                        <li><a href="<?php echo e(route('admin.subscribe')); ?>"><i class="fa fa-user-plus"></i> <span>Abunələr</span></a></li>
                        <li><a href="<?php echo e(route('clear.cache')); ?>"><i class="icon-spinner2 spinner"></i> <span>Keşi Təmizlə</span></a></li>
                        <li><a href="<?php echo e(route('admin.logout')); ?>"><i class="icon-switch2"></i> Çıxış</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div><?php /**PATH C:\Users\HP\Desktop\kabel\resources\views/back/layouts/include/main-navbar.blade.php ENDPATH**/ ?>