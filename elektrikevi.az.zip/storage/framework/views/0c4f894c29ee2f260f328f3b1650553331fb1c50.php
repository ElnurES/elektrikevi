<?php $__env->startComponent('mail::message'); ?>
Salam, Admin

    <?php echo e($contact->fullname); ?> adlı istifadəçi

    <?php echo e($contact->message); ?>


    mesajını gondərdi.




<?php $__env->startComponent('mail::button', ['url' => "mailto:".$contact->email]); ?>
Cavabla
<?php echo $__env->renderComponent(); ?>

Hörmətlə,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/emails/contact-notfication-mail-for-admin.blade.php ENDPATH**/ ?>