<?php if($cateqories->count()>0): ?>
   <?php $__currentLoopData = $cateqories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/back/render/get-child-category.blade.php ENDPATH**/ ?>