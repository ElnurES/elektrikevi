
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('page-header'); ?>
    <?php echo $__env->make('back.layouts.include.page-header',compact('crumbs'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
        <?php echo $__env->make('back.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Basic layout-->
            <form action="<?php echo e(route('admin.user.store')); ?>" class="form-horizontal" method="Post">
                <?php echo csrf_field(); ?>
                <div class="panel panel-flat">
                    <div class="panel-heading">
                        <h5 class="panel-title"><?php echo e($title); ?></h5>
                        <div class="heading-elements">
                            <a href="<?php echo e(route('admin.user')); ?>"><span class="label label-success">İSTİFADƏÇİLƏRƏ QAYIT</span></a>
                        </div>
                    </div>

                    <div class="panel-body">
                        <div class="form-group">
                            <label class="col-lg-3 control-label">Göstəriləcək Domen:</label>
                            <div class="col-lg-9">
                                <select  class="form-control" name="is_admin">
                                    <option value="0">İstifadəçi</option>
                                    <option value="1">Admin</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Ad Soayad:</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" name="fullname" value="<?php echo e(old('fullname')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Email:</label>
                            <div class="col-lg-9">
                                <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Ünvan:</label>
                            <div class="col-lg-9">
                                <textarea rows="3" cols="3" class="form-control" name="address" ><?php echo e(old('address')); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Mobil 1:</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" name="mobil_1" value="<?php echo e(old('mobil_1')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Mobil 2:</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" name="mobil_2" value="<?php echo e(old('mobil_2')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Şifrə:</label>
                            <div class="col-lg-9">
                                <input type="password" class="form-control" name="password" >
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Təkrar Şifrə:</label>
                            <div class="col-lg-9">
                                <input type="password" class="form-control" name="password_confirmation" >
                            </div>
                        </div>


                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Əlavə et <i class="icon-arrow-right14 position-right"></i></button>
                        </div>
                    </div>
                </div>
            </form>
            <!-- /basic layout -->
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/back/user/create.blade.php ENDPATH**/ ?>