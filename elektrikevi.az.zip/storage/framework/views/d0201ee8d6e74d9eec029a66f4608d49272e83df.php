<li class="menu-item-has-children"><a href="<?php echo e(route('catalog')); ?>">Məhsullar</a>
    <?php if(count($categories['categories']) >0): ?>
        <ul class="sub-menu">

            <?php $__currentLoopData = $categories['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="menu-item-has-children"><a href="<?php echo e(route('category',$category->slug)); ?>"><?php echo e($category->name); ?></a>
                    <?php if($category->child()->count()>0): ?>
                        <ul class="sub-menu">

                            <?php $__currentLoopData = $category->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('category',[$category->slug,$childCategory->slug])); ?>"><?php echo e($childCategory->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
    <?php endif; ?>
</li>
<?php /**PATH C:\Users\HP\Desktop\elektrikevi.az\resources\views/front/layouts/include/header-one-mobile.blade.php ENDPATH**/ ?>