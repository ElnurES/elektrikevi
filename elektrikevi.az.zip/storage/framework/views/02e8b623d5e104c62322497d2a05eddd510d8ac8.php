
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('head'); ?>

    <script type="text/javascript" src="/back/assets/js/plugins/forms/selects/select2.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/plugins/forms/styling/uniform.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/pages/form_layouts.js"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <?php echo $__env->make('back.layouts.include.page-header',compact('crumbs'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('back.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Basic layout-->
            <form action="<?php echo e(route('admin.category.store')); ?>" class="form-horizontal" method="Post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="panel panel-flat">
                    <div class="panel-heading">
                        <h5 class="panel-title"><?php echo e($title); ?></h5>
                        <div class="heading-elements">
                            <a href="<?php echo e(route('admin.category')); ?>"><span class="label label-success">KATEQORİYA LİSTİ</span></a>
                        </div>
                    </div>

                    <div class="panel-body">
                        <div class="form-group">
                            <label class="col-lg-3 control-label">Ad:</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Kateqoriyanın Növü:</label>
                            <div class="col-lg-9">
                                <label class="radio-inline">
                                    <input type="radio" class="styled" name="checkType" onchange="parentCheck(this)" >
                                    Üst Kateqoriya
                                </label>

                                <label class="radio-inline">
                                    <input type="radio" class="styled" name="checkType" onchange="childCheck(this)">
                                    Alt Kateqoriya
                                </label>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Üst Kateqoriya:</label>
                            <div class="col-lg-9">
                                <select class="select" name="parent_id" disabled id="parentId">
                                    <option>Üst Kateqoriyanı Seçin</option>
                                    <?php if($cateqories->count()>0): ?>
                                        <?php $__currentLoopData = $cateqories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Göstəriləcək Domen:</label>
                            <div class="col-lg-9">
                                <select  class="form-control" name="domain" disabled id="domain">
                                    <option>Domen Seçin</option>
                                    <?php if($domains->count()>0): ?>
                                        <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  value="<?php echo e($domain->id); ?>"><?php echo e($domain->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Şəkil:</label>
                            <div class="col-lg-9">
                                <input type="file" name="photo" id="categoryPhoto" class="file-styled" disabled>
                                <span class="help-block">Qəbul edilən uzantılar: gif, png, jpg, jpeg. Maksimum həcm 2Mb olmalıdır.</span>
                            </div>
                        </div>


                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Əlavə et <i class="icon-arrow-right14 position-right"></i></button>
                        </div>
                    </div>
                </div>
            </form>
            <!-- /basic layout -->
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
    <script>
        function parentCheck(checkbox) {
            var domain=document.getElementById('domain');
            var parentId=document.getElementById('parentId');
            var categoryPhoto=document.getElementById('categoryPhoto');

            if(checkbox.checked == true){
                parentId.disabled = true;
                domain.disabled = false;
                categoryPhoto.disabled = true;
            }
        }


        function childCheck(checkbox) {
            var domain=document.getElementById('domain');
            var parentId=document.getElementById('parentId');
            var categoryPhoto=document.getElementById('categoryPhoto');

            if(checkbox.checked == true){
                parentId.disabled = false;
                domain.disabled = true;
                categoryPhoto.disabled = false;
            }
        }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/back/category/create.blade.php ENDPATH**/ ?>