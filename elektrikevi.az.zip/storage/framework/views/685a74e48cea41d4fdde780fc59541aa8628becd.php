<?php $__env->startSection('title','Əsas Səhifə'); ?>
<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="/elnur/style.css">
    
    <style>
        .blog .carousel-indicators {
            left: 0;
            top: auto;
            bottom: -40px;

        }

        /* The colour of the indicators */
        .blog .carousel-indicators li {
            background: #a3a3a3;
            border-radius: 50%;
            width: 8px;
            height: 8px;
        }

        .blog .carousel-indicators .active {
            background: #707070;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('front.layouts.include.header-two',['desktopCategory'=>null,'mobileCategory'=>null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>

    <div class="page-content-area" >
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="about-top-content-wrapper">
                        <div class="row row-30">
                            <!-- About Content -->
                            <div class="about-content col-lg-12">
                                <?php echo $__env->make('front.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <section class="container menu-tags" id="menuTag">
                                    <div  class="slide">
                                        <a href="<?php echo e(route('kabel')); ?>">
                                            <div class="content">
                                                <h3>Kabel məhsulları</h3>
                                                <p>
                                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum nobis alias
                                                    maiores eaque
                                                    dolorem? A,
                                                    est recusandae cumque harum quo aliquid minus pariatur quasi odio placeat.
                                                    Voluptatem odio
                                                    molestias
                                                    est?
                                                </p>
                                            </div>
                                        </a>
                                    </div>
                                    <div  class="slide">
                                        <a href="<?php echo e(route('lamp')); ?>">
                                            <div class="content">
                                                <h3>İşıqlandırma</h3>
                                                <p>
                                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum nobis alias
                                                    maiores eaque
                                                    dolorem? A,
                                                    est recusandae cumque harum quo aliquid minus pariatur quasi odio placeat.
                                                    Voluptatem odio
                                                    molestias
                                                    est?
                                                </p>
                                            </div>
                                        </a>
                                    </div>
                                    <div  class="slide">
                                        <a href="<?php echo e(route('protected.device')); ?>">
                                            <div class="content">
                                                <h3>Mühavizə cihazları</h3>
                                                <p>
                                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum nobis alias
                                                    maiores eaque
                                                    dolorem? A,
                                                    est recusandae cumque harum quo aliquid minus pariatur quasi odio placeat.
                                                    Voluptatem odio
                                                    molestias
                                                    est?
                                                </p>
                                            </div>
                                        </a>
                                    </div>
                                    <div  class="slide">
                                        <a href="<?php echo e(route('kabel.aksesuar')); ?>">
                                            <div class="content">
                                                <h3>Kabel aksesuarları</h3>
                                                <p>
                                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum nobis alias
                                                    maiores eaque
                                                    dolorem? A,
                                                    est recusandae cumque harum quo aliquid minus pariatur quasi odio placeat.
                                                    Voluptatem odio
                                                    molestias
                                                    est?
                                                </p>
                                            </div>
                                        </a>
                                    </div>
                                    <div  class="slide">
                                        <a href="<?php echo e(route('skaf')); ?>">
                                            <div class="content">
                                                <h3>Şkaflar,qutular,aksesuarlar</h3>
                                                <p>
                                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum nobis alias
                                                    maiores eaque
                                                    dolorem? A,
                                                    est recusandae cumque harum quo aliquid minus pariatur quasi odio placeat.
                                                    Voluptatem odio
                                                    molestias
                                                    est?
                                                </p>
                                            </div>
                                        </a>
                                    </div>
                                    <div  class="slide">
                                        <a href="<?php echo e(route('elektrik')); ?>">
                                            <div class="content">
                                                <h3>Elektrik alətləri</h3>
                                                <p>
                                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum nobis alias
                                                    maiores eaque
                                                    dolorem? A,
                                                    est recusandae cumque harum quo aliquid minus pariatur quasi odio placeat.
                                                    Voluptatem odio
                                                    molestias
                                                    est?
                                                </p>
                                            </div>
                                        </a>
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="clearfix"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('latest-product'); ?>
    <div class="single-row-slider-area section-space">
        <div class="container">

            <div class="row blog">
                <div class="col-md-12">

                    <div id="blogCarousel" class="carousel slide" data-ride="carousel">

                        <ol class="carousel-indicators">

                            <li data-target="#blogCarousel" data-slide-to="0" class="active"></li>

                            <li data-target="#blogCarousel" data-slide-to="1"></li>

                        </ol>

                        <!-- Carousel items -->

                        <div class="carousel-inner">

                            <div class="carousel-item active">

                                <div class="row">

                                    <div class="col-3">

                                        <a href="#">

                                            <img src="<?php echo e(asset('elnur/customer/Z-1.png')); ?>" alt="Image" style="max-width:100%;">

                                        </a>

                                    </div>

                                    <div class="col-3">

                                        <a href="#">

                                            <img src="<?php echo e(asset('elnur/customer/Z-2.png')); ?>" alt="Image" style="max-width:100%;">

                                        </a>

                                    </div>

                                    <div class="col-3">

                                        <a href="#">

                                            <img src="<?php echo e(asset('elnur/customer/Z-3.png')); ?>" alt="Image" style="max-width:100%;">

                                        </a>

                                    </div>

                                    <div class="col-3">

                                        <a href="#">

                                            <img src="<?php echo e(asset('elnur/customer/Z-4.png')); ?>" alt="Image" style="max-width:100%;">

                                        </a>

                                    </div>

                                </div>

                                <!--.row-->

                            </div>

                            <!--.item-->

                            <div class="carousel-item">

                                <div class="row">

                                    <div class="col-3">

                                        <a href="#">

                                            <img src="<?php echo e(asset('elnur/customer/Z-5.png')); ?>" alt="Image" style="max-width:100%;">

                                        </a>

                                    </div>

                                    <div class="col-3">

                                        <a href="#">

                                            <img src="<?php echo e(asset('elnur/customer/Z-6.png')); ?>" alt="Image" style="max-width:100%;">

                                        </a>

                                    </div>

                                    <div class="col-3">

                                        <a href="#">

                                            <img src="<?php echo e(asset('elnur/customer/Z-7.png')); ?>" alt="Image" style="max-width:100%;">

                                        </a>

                                    </div>

                                    <div class="col-3">

                                        <a href="#">

                                            <img src="<?php echo e(asset('elnur/customer/Z-8.png')); ?>" alt="Image" style="max-width:100%;">

                                        </a>

                                    </div>

                                </div>

                                <!--.row-->

                            </div>

                            <!--.item-->

                        </div>

                        <!--.carousel-inner-->

                    </div>

                    <!--.Carousel-->

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('product-modal'); ?>
    <div class="product-modal modal fade quick-view-modal-container" id="quick-view-modal-container" tabindex="-1" role="dialog" aria-hidden="true">

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
    <script>

        // optional

        $('#blogCarousel').carousel({

            interval: 5000

        });

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\kabel\resources\views/front/index.blade.php ENDPATH**/ ?>