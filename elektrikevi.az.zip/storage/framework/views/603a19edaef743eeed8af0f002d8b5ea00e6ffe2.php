<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('front.layouts.include.header-two',['desktopCategory'=>$desktopCategory,'mobileCategory'=>$mobileCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('front.layouts.include.breadcrumb',compact('crumbs','title'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="page-content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!--=======  page wrapper  =======-->
                    <div class="page-wrapper">
                        <div class="page-content-wrapper">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-xs-12 col-lg-12">
                                <?php echo $__env->make('front.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <!-- Login Form s-->
                                    <form action="<?php echo e(route('login')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="login-form">
                                            <h4 class="login-title">Giriş</h4>

                                            <div class="row">
                                                <div class="col-md-12 col-12">
                                                    <label>E-poçt*</label>
                                                    <input type="email"  name="email" value="<?php echo e(old('email')); ?>">
                                                </div>
                                                <div class="col-12">
                                                    <label>Şifrə</label>
                                                    <input type="password"  name="password">
                                                </div>
                                                <div class="col-sm-6">

                                                    <div class="check-box d-inline-block ml-0 ml-md-2">
                                                        <input type="checkbox" id="remember_me" name="rememberme">
                                                        <label for="remember_me">Məni xatırla</label>
                                                    </div>

                                                </div>

                                                <div class="col-sm-6 text-left text-sm-right">
                                                    <a href="<?php echo e(route('reset-password')); ?>" class="forget-pass-link"> Şifrəni unutmusunuz?</a>
                                                </div>

                                                <div class="col-md-12">
                                                    <button class="register-button">Gİrİş</button>
                                                </div>

                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--=======  End of page wrapper  =======-->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\elektrikevi.az\resources\views/front/auth/login.blade.php ENDPATH**/ ?>