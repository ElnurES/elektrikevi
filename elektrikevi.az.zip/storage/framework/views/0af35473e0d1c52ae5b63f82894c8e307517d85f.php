
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('front.layouts.include.header-two',['desktopCategory'=>$desktopCategory,'mobileCategory'=>$mobileCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('front.layouts.include.breadcrumb',compact('crumbs','title'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="page-content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!--=======  page wrapper  =======-->
                    <div class="page-wrapper">
                        <div class="page-content-wrapper">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">
                                    <?php echo $__env->make('front.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <form action="<?php echo e(route('register')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="login-form">
                                            <h4 class="login-title">Qeydiyyat</h4>

                                            <div class="row">
                                                <div class="col-md-12 col-12 mb-20">
                                                    <label>Ad Soyad*</label>
                                                    <input type="text" name="fullname" required value="<?php echo e(old('fullname')); ?>">
                                                </div>
                                                <div class="col-md-12 mb-20">
                                                    <label>E-poçt*</label>
                                                    <input type="email" name="email" required value="<?php echo e(old('email')); ?>">
                                                </div>
                                                <div class="col-md-6 mb-20">
                                                    <label>Şifrə*</label>
                                                    <input type="password" name="password" required>
                                                </div>
                                                <div class="col-md-6 mb-20">
                                                    <label>Təkrar Şifrə*</label>
                                                    <input type="password" name="password_confirmation" required>
                                                </div>
                                                <div class="col-12">
                                                    <button class="register-button mt-0">QEYDİYYAT</button>
                                                </div>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--=======  End of page wrapper  =======-->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/front/auth/register.blade.php ENDPATH**/ ?>