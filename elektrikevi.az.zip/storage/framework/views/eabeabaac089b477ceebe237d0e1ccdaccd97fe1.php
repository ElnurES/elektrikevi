
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('head'); ?>

    <!-- Theme JS files -->
    <script type="text/javascript" src="/back/assets/js/plugins/tables/datatables/datatables.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/plugins/tables/datatables/extensions/responsive.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/plugins/forms/selects/select2.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/pages/datatables_responsive.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <?php echo $__env->make('back.layouts.include.page-header',compact('crumbs'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('back.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="panel panel-flat">
        <div class="panel-heading">
            <h5 class="panel-title"><?php echo e($title); ?></h5>
            <div class="heading-elements">
                <a href="<?php echo e(route('admin.category')); ?>"><span class="label label-success">KATEQORİYA LİSTİ</span></a>
            </div>
        </div>

        <table class="table datatable-responsive-row-control">
            <thead>
            <tr>
                <th></th>
                <th>Şəkil</th>
                <th>Ad</th>
                <th>Slug</th>
                <th>Məhsul Kodu</th>
                <th>Qiymət</th>
                <th>Stok Miqdarı</th>
                <th>Status</th>
                <th>Domain</th>
                <th>Yenilənmə Tarixi</th>
            </tr>
            </thead>
            <tbody>
            <?php if($categoryProducts->product->count()>0): ?>
                <?php $__currentLoopData = $categoryProducts->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td>
                            <a href="<?php echo e(route('admin.product.edit',$product->slug)); ?>">
                                <img style="width: 50px;" src="<?php echo e(asset("uploads/product").'/'.$product->parentPhoto()->photo); ?>"  alt="">
                            </a>
                        </td>
                        <td><a href="<?php echo e(route('admin.product.edit',$product->slug)); ?>"><?php echo e($product->name); ?></a></td>
                        <td><a href="<?php echo e(route('admin.product.edit',$product->slug)); ?>"><?php echo e($product->slug); ?></a></td>
                        <td><a href="<?php echo e(route('admin.product.edit',$product->slug)); ?>"><?php echo e($product->code); ?></a></td>
                        <td><a href="<?php echo e(route('admin.product.edit',$product->slug)); ?>"><?php echo ($product->discount==1) ? "<strike>$product->price</strike> $product->discount_price" : "$product->price"; ?></a></td>
                        <td><a href="<?php echo e(route('admin.product.edit',$product->slug)); ?>"><?php echo e($product->stock_count); ?></a></td>
                        <td><span class="label label-info"><?php echo e($product->status->name); ?></span></td>
                        <td><span class="label label-success"><?php echo e($product->productDomain->name); ?></span></td>
                        <td><?php echo e($product->product_updated_at_no_pm()); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/back/category/product.blade.php ENDPATH**/ ?>