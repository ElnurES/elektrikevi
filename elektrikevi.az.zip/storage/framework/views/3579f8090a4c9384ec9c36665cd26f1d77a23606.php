<?php if(Cart::count()>0): ?>
    <div class="cart-items-wrapper ps-scroll">
        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single-cart-item">
                <a  href="<?php echo e(route('removeFromCartByRowId',$cart->rowId)); ?>" class="remove-icon"><i class="ion-android-close"></i></a>
                <div class="image">
                    <a href="<?php echo e(route('product.detail',$cart->options->slug)); ?>">
                        <img src="<?php echo e(asset("uploads/product").'/'.$cart->options->photo); ?>" class="img-fluid" alt="<?php echo e($cart->options->photo); ?>">
                    </a>
                </div>
                <div class="content">
                    <p class="product-title"><a href="<?php echo e(route('product.detail',$cart->options->slug)); ?>"><?php echo e($cart->name); ?></a></p>
                    <p class="count"><span><?php echo e($cart->qty); ?> x </span><?php echo e($cart->price); ?> ₼</p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="cart-calculation">
        <table class="table">
            <tbody>
            <tr>
                <td class="text-left">Cəmi :</td>
                <td class="text-right"><?php echo e(Cart::subtotal()); ?> ₼</td>
            </tr>
            <tr>
                <td class="text-left">ƏDV (0%) :</td>
                <td class="text-right"><?php echo e(Cart::tax()); ?> ₼</td>
            </tr>
            <tr>
                <td class="text-left">Cəmi(Ədv ilə) :</td>
                <td class="text-right"><?php echo e(Cart::total()); ?> ₼</td>
            </tr>
            </tbody>
        </table>
    </div>
    <div class="cart-buttons">
        <a href="<?php echo e(route('cart')); ?>">Səbət</a>
        <a href="<?php echo e(route('checkout')); ?>">Sİfarİşİ rəsmİləşdİr</a>
    </div>
    <?php else: ?>
    <div class="alert alert-info" role="alert">
        Səbətiniz boşdur!
    </div>
<?php endif; ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/front/render/header-cart-item.blade.php ENDPATH**/ ?>