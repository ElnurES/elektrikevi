<?php $__env->startComponent('mail::message'); ?>
    <?php echo e(config('app.name')); ?>


    Yeni məhsullarımız,endirimlərimiz haqqında ilk siz xəbərdar olacaqsınız.

    Hörmətlə,<br>
    <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/emails/subscribe-notfication-mail.blade.php ENDPATH**/ ?>