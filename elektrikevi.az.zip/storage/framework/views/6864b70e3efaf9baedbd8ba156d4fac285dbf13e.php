<?php $__env->startComponent('mail::message'); ?>
    <?php echo e(config('app.name')); ?>


    Salam <?php echo e($order->fullname); ?>, yeni sifariş verdiniz
    İstifadəçi panelinizdən sifarişinizi izləyə bilərsiniz.
    Bunu keçid düyməsinə klikləyərək və ya aşağdakı linki brauzernizdə açaraq edə bilərsiniz

    <?php echo e(route('my-account')); ?>


    <?php $__env->startComponent('mail::button', ['url' =>route('my-account') ]); ?>
        Keçid
    <?php echo $__env->renderComponent(); ?>

    Hörmətlə,
    <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\HP\Desktop\elektrikevi.az\resources\views/emails/user-order-info-mail.blade.php ENDPATH**/ ?>