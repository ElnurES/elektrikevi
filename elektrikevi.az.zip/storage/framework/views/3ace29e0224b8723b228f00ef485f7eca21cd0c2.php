
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('head'); ?>
    <script type="text/javascript" src="/back/assets/js/plugins/forms/selects/select2.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/plugins/forms/styling/uniform.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/pages/form_layouts.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <?php echo $__env->make('back.layouts.include.page-header',compact('crumbs'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
        <?php echo $__env->make('back.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Basic layout-->
            <form action="<?php echo e(route('admin.config.update',$config->id)); ?>" class="form-horizontal" method="Post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="panel panel-flat">
                    <div class="panel-heading">
                        <h5 class="panel-title"><?php echo e($title); ?></h5>

                    </div>

                    <div class="panel-body">
                        <div class="form-group">
                            <label class="col-lg-3 control-label">Ünvan:</label>
                            <div class="col-lg-9">
                                <textarea rows="3" cols="3" class="form-control" name="location" ><?php echo e($config->location); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Mobil 1:</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" name="mobil_1" value="<?php echo e($config->mobil_1); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Mobil 2:</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" name="mobil_2" value="<?php echo e($config->mobil_2); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Email:</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" name="email" value="<?php echo e($config->email); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Facebook:</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" name="facebook" value="<?php echo e($config->facebook); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">İnstagram:</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" name="instagram" value="<?php echo e($config->instagram); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Youtube:</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" name="youtube" value="<?php echo e($config->youtube); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label">Logo:</label>
                            <div class="col-lg-9">
                                <div class="thumbnail" style="width: 30%">
                                    <div class="thumb">
                                        <img src="<?php echo e(asset("uploads/logo").'/'.$config->logo); ?>" alt="">
                                        <div class="caption-overflow">
										<span>
											<a href="<?php echo e(route('home')); ?>" data-popup="lightbox" rel="gallery" class="btn border-white text-white btn-flat btn-icon btn-rounded"><i class="icon-plus3"></i></a>
										</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-lg-3 control-label"></label>
                            <div class="col-lg-9">
                                <input type="file" name="photo" id="productPhoto" class="file-styled" >
                                <span class="help-block">Qəbul edilən uzantılar: gif, png, jpg, jpeg. Maksimum həcm 2Mb olmalıdır.</span>
                            </div>
                        </div>


                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Yenilə <i class="icon-arrow-right14 position-right"></i></button>
                        </div>
                    </div>
                </div>
            </form>
            <!-- /basic layout -->
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/back/config.blade.php ENDPATH**/ ?>