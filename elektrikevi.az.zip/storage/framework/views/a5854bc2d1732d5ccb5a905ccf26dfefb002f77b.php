<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php echo $__env->make('back.layouts.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('head'); ?>
</head>

<body>

<!-- Main navbar -->
<?php echo $__env->make('back.layouts.include.main-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /main navbar -->


<!-- Page container -->
<div class="page-container">

    <!-- Page content -->
    <div class="page-content">

        <!-- Main sidebar -->
        <?php echo $__env->make('back.layouts.include.main-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /main sidebar -->


        <!-- Main content -->
        <div class="content-wrapper">

            <!-- Page header -->
            <?php echo $__env->yieldContent('page-header'); ?>
            <!-- /page header -->


            <!-- Content area -->
            <div class="content">

                <?php echo $__env->yieldContent('content'); ?>

                <!-- Footer -->
                <div class="footer text-muted">
                    Məxfilik siyasəti © <?php echo e(date('Y')); ?> <a >Elektrikevi. Bütün hüquqlar qorunur.</a>
                </div>
                <!-- /footer -->

            </div>
            <!-- /content area -->

        </div>
        <!-- /main content -->

    </div>
    <!-- /page content -->

</div>
<!-- /page container -->

</body>
</html>

<?php echo $__env->yieldContent('foot'); ?>
<script>
    setTimeout(function () {
        $('.msj').slideUp(500);
    },5000)
</script>

<?php /**PATH C:\Users\HP\Desktop\kabel\resources\views/back/layouts/master.blade.php ENDPATH**/ ?>