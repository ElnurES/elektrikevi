<?php $__env->startComponent('mail::message'); ?>
    <?php echo e(config('app.name')); ?>


    Salam <?php echo e($user->fullname); ?>, uğurla qeydiyyatdan keçdiniz
    Profilinizi aktivləşdirmək üçün  Təstiqlə düyməsinə kilikləyin və ya aşağdakı bağlantıyı brauzerinizdə açın.
    <?php echo e(config('app.url')); ?>/auth/activation/<?php echo e($user->activation); ?>



<?php $__env->startComponent('mail::button', ['url' =>route('activation',$user->activation) ]); ?>
    Təstiqlə
<?php echo $__env->renderComponent(); ?>

Hörmətlə,
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/emails/user-activation-mail.blade.php ENDPATH**/ ?>