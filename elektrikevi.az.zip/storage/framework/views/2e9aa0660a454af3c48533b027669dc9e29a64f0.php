<?php $__env->startComponent('mail::message'); ?>
    <?php echo e(config('app.name')); ?>


    Salam Admin, yeni sifariş var

    linkini admin panelde yazandan sora veresik ola bilsin:))
    <?php echo e(route('my-account')); ?>



    <?php $__env->startComponent('mail::button', ['url' =>route('my-account') ]); ?>
        Keçid
    <?php echo $__env->renderComponent(); ?>

    Hörmətlə,
    <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/emails/admin-order-info-mail.blade.php ENDPATH**/ ?>