<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('front.layouts.include.header-two',['desktopCategory'=>$desktopCategory,'mobileCategory'=>$mobileCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?>
    <style>
        .cart-summary {
            /*float: right;*/
            width: 100%;
            max-width: 100%!important;
            margin-left: auto;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('front.layouts.include.breadcrumb',compact('crumbs','title'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="page-content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!--=======  page wrapper  =======-->
                    <div class="page-wrapper">
                        <div class="page-content-wrapper">
                            <?php echo $__env->make('front.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <!--=======  cart table  =======-->
                                <div class="cart-table table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th class="pro-thumbnail"></th>
                                            <th class="pro-title">Ad</th>
                                            <th class="pro-price">Alış Qİymətİ</th>
                                            <th class="pro-quantity">Ədəd</th>
                                            <th class="pro-subtotal">Cəmİ</th>
                                        </tr>
                                        </thead>
                                        <tbody class="cartTable">

                                        <?php $__currentLoopData = $order->basket->basket_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="pro-thumbnail">
                                                    <a href="<?php echo e(route('product.detail',$basket->product->slug)); ?>">
                                                        <img src="<?php echo e(asset("uploads/product").'/'.$basket->product->parentPhoto()->photo); ?>" class="img-fluid" alt="<?php echo e($basket->product->name); ?>">
                                                    </a>
                                                </td>
                                                <td class="pro-title"><a class="locationChoose" href="<?php echo e(route('product.detail',$basket->product->slug)); ?>"><?php echo e($basket->product->name); ?></a></td>
                                                <td class="pro-price"><span>$<?php echo e($basket->price); ?></span></td>
                                                <td class="pro-quantity">
                                                    <?php echo e($basket->count); ?>

                                                </td>
                                                <td class="pro-subtotal"><span>$<?php echo e($basket->count*$basket->price); ?></span></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12 col-12 d-flex">
                                        <!--=======  Cart summery  =======-->

                                        <div class="cart-summary">
                                            <div class="cart-summary-wrap">
                                                <p>Cəmi <span>$<?php echo e($order->sub_total); ?></span></p>
                                                <p>ƏDV (21%)  <span>$<?php echo e($order->order_total-$order->sub_total); ?></span></p>
                                                <h2>Cəmi(Ədv ilə) <span>$<?php echo e($order->order_total); ?></span></h2>
                                            </div>
                                        </div>

                                        <!--=======  End of Cart summery  =======-->

                                    </div>

                                </div>
                                <!--=======  End of cart table  =======-->
                        </div>
                    </div>
                    <!--=======  End of page wrapper  =======-->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\elektrikevi.az\resources\views/front/order/detail.blade.php ENDPATH**/ ?>