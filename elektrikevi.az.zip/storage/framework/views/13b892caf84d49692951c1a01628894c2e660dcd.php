<div class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <!--=======  header wrapper  =======-->
                <div class="header-wrapper d-none d-lg-flex">
                    <!-- logo -->
                    <div class="logo">
                        <a href="<?php echo e(route('home')); ?>">
                            <img src="/uploads/logo/<?php echo e($config->logo); ?>" class="img-fluid" style="width:80%;"  alt="elektrikevi_<?php echo e($config->logo); ?>">
                        </a>
                    </div>
                    <?php
                        $links=['about','delivery','contact'];
                    ?>
                    <!-- menu wrapper -->
                    <div class="navigation-menu-wrapper">
                        <nav>
                            <ul style="margin-bottom: auto !important;">
                                <li><a href="<?php echo e(route('home')); ?>">Əsas Səhifə</a></li>
                                
                                <li class="menu-item-has-children"><a>Mağaza</a>
                                    <ul class="sub-menu">
                                        <li><a href="<?php echo e(route('kabel')); ?>">Kabel məhsulları</a></li>
                                        <li><a href="<?php echo e(route('lamp')); ?>">İşıqlandırma</a></li>
                                        <li><a href="<?php echo e(route('protected.device')); ?>">Mühavizə cihazları</a></li>
                                        <li><a href="<?php echo e(route('kabel.aksesuar')); ?>">Kabel aksesuarları</a></li>
                                        <li><a href="<?php echo e(route('skaf')); ?>">Şkaflar,qutular,aksesuarlar</a></li>
                                        <li><a href="<?php echo e(route('elektrik')); ?>">Elektrik alətləri</a></li>
                                    </ul>
                                </li>
                                <?php if(!in_array(request()->segment(1),$links)): ?>
                                    <?php echo $desktopCategory; ?>

                                <?php endif; ?>
                                <li><a href="<?php echo e(route('contact')); ?>">Əlaqə</a></li>
                                <li><a href="<?php echo e(route('about')); ?>">Haqqımızda</a></li>
                                <li><a href="<?php echo e(route('delivery')); ?>">Suallar</a></li>
                            </ul>
                        </nav>
                    </div>
                    <!-- header icon -->
                    <div class="header-icon-wrapper">
                        <ul class="icon-list" style="margin-bottom: auto !important;">
                            <li>
                                <a href="javascript:void(0)" id="search-overlay-trigger">
                                    <i class="ion-ios-search-strong"></i>
                                </a>
                            </li>
                            <li>
                                <div class="header-cart-icon">
                                    <a href="<?php echo e(route('cart')); ?>" id="minicart-trigger">
                                        <i class="ion-bag"></i>
                                        <span class="counter basketCounter"><?php echo e(Cart::count()); ?></span>
                                    </a>
                                    <!-- mini cart  -->
                                    <div class="mini-cart" id="mini-cart" style="max-height: 600px; overflow: auto;">
                                        <?php if(Cart::count()>0): ?>
                                            <div class="cart-items-wrapper ps-scroll">
                                                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="single-cart-item">
                                                        <a href="<?php echo e(route('removeFromCartByRowId',$cart->rowId)); ?>" class="remove-icon"><i class="ion-android-close"></i></a>
                                                        <div class="image">
                                                            <a href="<?php echo e(route('product.detail',$cart->options->slug)); ?>">
                                                                <img src="<?php echo e(asset("uploads/product").'/'.$cart->options->photo); ?>" class="img-fluid" alt="<?php echo e($cart->options->photo); ?>">
                                                            </a>
                                                        </div>
                                                        <div class="content">
                                                            <p class="product-title"><a href="<?php echo e(route('product.detail',$cart->options->slug)); ?>"><?php echo e($cart->name); ?></a></p>
                                                            <p class="count"><span><?php echo e($cart->qty); ?> x </span> $<?php echo e($cart->price); ?></p>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <div class="cart-calculation">
                                                <table class="table">
                                                    <tbody>
                                                    <tr>
                                                        <td class="text-left">Cəmi :</td>
                                                        <td class="text-right">$<?php echo e(Cart::subtotal()); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-left">ƏDV (0%) :</td>
                                                        <td class="text-right">$<?php echo e(Cart::tax()); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-left">Cəmi(Ədv İlə) :</td>
                                                        <td class="text-right">$<?php echo e(Cart::total()); ?></td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="cart-buttons">
                                                <a href="<?php echo e(route('cart')); ?>">Səbət</a>
                                                <a href="<?php echo e(route('checkout')); ?>">Sİfarİşİ rəsmİləşdİr</a>
                                            </div>
                                            <?php else: ?>
                                                <div class="alert alert-info" role="alert">
                                                    Səbətiniz boşdur!
                                                </div>
                                            <?php endif; ?>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="header-cart-icon">
                                    <a href="<?php echo e(route('wishlist')); ?>" id="minicart-trigger">
                                        <i class="ion-heart"></i>
                                        <span class="counter wishlistCounter"><?php echo e($wishlistCount!=0 ? $wishlistCount : 0); ?> </span>
                                    </a>

                                </div>
                            </li>
                            <li>
                                <div class="header-cart-icon">
                                    <a href="<?php echo e(route('compare')); ?>" id="minicart-trigger">
                                        <i class="ion-android-options"></i>
                                        <span class="counter compareCounter"><?php echo e($compareCount!=0 ? $compareCount : 0); ?></span>
                                    </a>

                                </div>
                            </li>
                            <li>
                                <div class="header-settings-icon">
                                    <a href="javascript:void(0)" class="header-settings-trigger" id="header-settings-trigger">
                                        <div class="setting-button">
                                            <span></span>
                                            <span></span>
                                            <span></span>
                                        </div>
                                    </a>

                                    <!-- settings menu -->
                                    <div class="settings-menu-wrapper" id="settings-menu-wrapper">
                                        <div class="single-settings-block">
                                            <h4 class="title">Şəxsi Kabinet</h4>
                                            <ul>
                                                <?php if(auth()->guard()->guest()): ?>
                                                    <li><a href="<?php echo e(route('login')); ?>">Giriş</a></li>
                                                    <li><a href="<?php echo e(route('register')); ?>">Qeydiyyat</a></li>
                                                <?php endif; ?>
                                                <?php if(auth()->guard()->check()): ?>
                                                    <li><a href="<?php echo e(route('my-account')); ?>">İstifadəçi Paneli</a></li>
                                                    <li><a href="<?php echo e(route('logout')); ?>">Çıxış</a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                        <div class="single-settings-block">
                                            <h4 class="title">Valyuta Məzənnəsi </h4>
                                            <ul>
                                                <?php if(count($currencys)>0): ?>
                                                    <?php $__currentLoopData = $currencys['currencys']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a style="margin-right: 2em;"><?php echo e($key); ?></a><?php echo e($value); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <!--=======  End of header wrapper  =======-->

                <!--=======  mobile navigation area  =======-->

                <div class="header-mobile-navigation d-block d-lg-none">
                    <div class="row align-items-center">
                        <div class="col-6 col-md-6">
                            <div class="header-logo">
                                <a href="<?php echo e(route('home')); ?>">
                                    <img src="/uploads/logo/<?php echo e($config->logo); ?>" class="img-fluid" alt="elektrikevi_<?php echo e($config->logo); ?>">
                                </a>
                            </div>
                        </div>
                        <div class="col-6 col-md-6">
                            <div class="mobile-navigation text-right">
                                <div class="header-icon-wrapper">
                                    <ul class="icon-list justify-content-end">
                                        <li>
                                            <div class="header-cart-icon">
                                                <a href="<?php echo e(route('cart')); ?>">
                                                    <i class="ion-bag"></i>
                                                    <span class="counter basketCounter"><?php echo e(Cart::count()); ?></span>
                                                </a>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="header-cart-icon">
                                                <a href="<?php echo e(route('wishlist')); ?>" id="minicart-trigger">
                                                    <i class="ion-heart"></i>
                                                    <span class="counter wishlistCounter"><?php echo e($wishlistCount!=0 ? $wishlistCount : 0); ?> </span>
                                                </a>

                                            </div>
                                        </li>
                                        <li>
                                            <div class="header-cart-icon">
                                                <a href="<?php echo e(route('compare')); ?>" id="minicart-trigger">
                                                    <i class="ion-android-options"></i>
                                                    <span class="counter compareCounter"><?php echo e($compareCount!=0 ? $compareCount : 0); ?></span>
                                                </a>

                                            </div>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0)" class="mobile-menu-icon" id="mobile-menu-trigger"><i class="fa fa-bars"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--=======  End of mobile navigation area  =======-->

            </div>
        </div>
    </div>
</div>






<!--=======  offcanvas mobile menu  =======-->
<div class="offcanvas-mobile-menu" id="offcanvas-mobile-menu">
    <a href="javascript:void(0)" class="offcanvas-menu-close" id="offcanvas-menu-close-trigger">
        <i class="ion-android-close"></i>
    </a>

    <div class="offcanvas-wrapper">

        <div class="offcanvas-inner-content">
            <div class="offcanvas-mobile-search-area">
                <form action="<?php echo e(route('product.search')); ?>" method="Get">
                    <input type="search" placeholder="Axtar ..." name="search">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
            <nav class="offcanvas-navigation">
                <ul>
                    <li><a href="<?php echo e(route('home')); ?>">Əsas Səhifə</a></li>
                    <?php if(!in_array(request()->segment(1),$links)): ?>
                        <?php echo $mobileCategory; ?>

                    <?php endif; ?>

                    <li class="menu-item-has-children"><a>Mağaza</a>
                        <ul class="sub-menu">
                            <li><a href="<?php echo e(route('kabel')); ?>">Kabel məhsulları</a></li>
                            <li><a href="<?php echo e(route('lamp')); ?>">İşıqlandırma</a></li>
                            <li><a href="<?php echo e(route('protected.device')); ?>">Mühavizə cihazları</a></li>
                            <li><a href="<?php echo e(route('kabel.aksesuar')); ?>">Kabel aksesuarları</a></li>
                            <li><a href="<?php echo e(route('skaf')); ?>">Şkaflar,qutular,aksesuarlar</a></li>
                            <li><a href="<?php echo e(route('elektrik')); ?>">Elektrik alətləri</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(route('contact')); ?>">Əlaqə</a></li>
                    <li><a href="<?php echo e(route('about')); ?>">Haqqımızda</a></li>
                    <li><a href="<?php echo e(route('delivery')); ?>">Sualar</a></li>
                </ul>
            </nav>

            <div class="offcanvas-settings">
                <nav class="offcanvas-navigation">
                    <ul>
                        <li class="menu-item-has-children"><a >Şəxsi Kabinet </a>
                            <ul class="sub-menu">
                                <?php if(auth()->guard()->guest()): ?>
                                    <li><a href="<?php echo e(route('login')); ?>">Giriş</a></li>
                                    <li><a href="<?php echo e(route('register')); ?>">Qeydiyyat</a></li>
                                <?php endif; ?>
                                <?php if(auth()->guard()->check()): ?>
                                    <li><a href="<?php echo e(route('my-account')); ?>">İstifadəçi Paneli</a></li>
                                    <li><a href="<?php echo e(route('logout')); ?>">Çıxış</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                        <li class="menu-item-has-children"><a href="#">Valyuta Məzənnəsi </a>
                            <ul class="sub-menu">
                                <?php if(count($currencys)>0): ?>
                                    <?php $__currentLoopData = $currencys['currencys']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a ><?php echo e($key); ?> <span style="float: right"><?php echo e($value); ?></span></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>

            <div class="offcanvas-widget-area">
                <div class="off-canvas-contact-widget">
                    <div class="header-contact-info">
                        <ul class="header-contact-info__list">
                            <li><i class="ion-android-phone-portrait"></i> <a href="tel://<?php echo e($config->mobil_1); ?>"><?php echo e($config->mobil_1); ?> </a></li>
                            <li><i class="ion-android-phone-portrait"></i> <a href="tel://<?php echo e($config->mobil_2); ?>"><?php echo e($config->mobil_2); ?> </a></li>
                            <li><i class="ion-android-mail"></i> <a href="mailto:<?php echo e($config->email); ?>"><?php echo e($config->email); ?></a></li>
                        </ul>
                    </div>
                </div>
                <!--Off Canvas Widget Social Start-->
                <div class="off-canvas-widget-social">
                    <a href="<?php echo e($config->facebook); ?>"><i class="fa fa-facebook"></i></a>
                    <a href="<?php echo e($config->instagram); ?>"><i class="fa fa-instagram"></i></a>
                    <a href="mailto:<?php echo e($config->email); ?>"><i class="fa fa-envelope"></i></a>
                    <a href="<?php echo e($config->youtube); ?>"><i class="fa fa-youtube"></i></a>
                </div>
                <!--Off Canvas Widget Social End-->
            </div>
        </div>
    </div>

</div>
<!--=======  End of offcanvas mobile menu  =======--><?php /**PATH C:\Users\HP\Desktop\elektrikevi.az\resources\views/front/layouts/include/header-two.blade.php ENDPATH**/ ?>