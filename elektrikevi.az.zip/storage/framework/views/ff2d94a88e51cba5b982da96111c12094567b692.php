
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('front.layouts.include.header-two',['desktopCategory'=>$desktopCategory,'mobileCategory'=>$mobileCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('front.layouts.include.breadcrumb',compact('crumbs','title'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="page-content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!--=======  page wrapper  =======-->
                    <div class="page-wrapper">
                        <div class="page-content-wrapper">
                        <?php echo $__env->make('front.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!-- Checkout Form s-->
                            <form action="<?php echo e(route('checkout')); ?>" class="checkout-form" method="Post">
                                <?php echo csrf_field(); ?>
                                <div class="row row-40">
                                    <div class="col-lg-7">
                                        <!-- Billing Address -->
                                        <div id="billing-form">
                                            <h4 class="checkout-title">Çatdırılma ünvanı</h4>

                                            <div class="row">

                                                <div class="col-md-6 col-md-12">
                                                    <label>Ad Soyad*</label>
                                                    <input type="text" name="fullname" value="<?php echo e($user->fullname); ?>">
                                                </div>

                                                <div class="col-md-6 col-12">
                                                    <label>E-Poçt*</label>
                                                    <input type="email" name="email" value="<?php echo e($user->email); ?>">
                                                </div>

                                                <div class="col-md-6 col-12">
                                                    <label>Telefon*</label>
                                                    <input type="text" name="mobil" value="<?php echo e($user->detail->mobil_1); ?>">
                                                </div>

                                                <div class="col-md-6 col-12">
                                                    <label>Şəhər/Rayon*</label>
                                                    <input type="text" name="city">
                                                </div>

                                                <div class="col-md-6 col-12">
                                                    <label>Rayon*</label>
                                                    <input type="text" name="region">
                                                </div>

                                                <div class="col-md-6 col-12">
                                                    <label>Küçə*</label>
                                                    <input type="text" name="street">
                                                </div>

                                                <div class="col-md-6 col-12">
                                                    <label>Poçt İndeks Kodu*</label>
                                                    <input type="text" name="zip_code">
                                                </div>

                                                <div class="col-12">
                                                    <label>Ünvan/Ətraflı*</label>
                                                    <textarea rows="7" style="width: 100%;" class="form-group" name="adress"><?php echo e($user->detail->address); ?></textarea>
                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="col-lg-5">
                                        <div class="row">

                                            <!-- Cart Total -->
                                            <div class="col-12">

                                                <h4 class="checkout-title">Sifarişim</h4>

                                                <div class="checkout-cart-total">

                                                    <h4>Məhsul <span>Cəmi</span></h4>

                                                    <ul>
                                                        <?php if(Cart::count()>0): ?>
                                                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><a href="<?php echo e(route('product.detail',$cart->options->slug)); ?>"><?php echo e($cart->name); ?></a>   X  <span>$<?php echo e($cart->price); ?></span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </ul>

                                                    <p>Cəmi <span>$<?php echo e(Cart::subtotal()); ?></span></p>
                                                    <p>Ünvan çatdırılma <span>$00.00</span></p>
                                                    <p>ƏDV (21%)  <span>$<?php echo e(Cart::tax()); ?></span></p>
                                                    <h4>Cəmi(Ədv ilə) <span>$<?php echo e(Cart::total()); ?></span></h4>

                                                </div>

                                            </div>

                                            <!-- Payment Method -->
                                            <div class="col-12">

                                                <h4 class="checkout-title">Ödəniş növü</h4>

                                                <div class="checkout-payment-method">

                                                    <div class="single-method">
                                                        <input type="radio" id="payment_check" name="payment-method" value="1">
                                                        <label for="payment_check">Çatdırılma zamanı nağd ödəniş</label>
                                                        <p data-method="1">Bu ödəmə usulu ilə səbətdəki məhsullar iki günlüyünə sizin adınıza bron edilir.
                                                            İki gün ərzində ödəmə edilməzsə sifariş adınızdan çıxarılır.</p>
                                                    </div>

                                                    <div class="single-method">
                                                        <input type="radio" id="payment_bank" disabled name="payment-method" value="bank">
                                                        <label for="payment_bank">Visa / Mastercard</label>
                                                        <p data-method="bank">Please send a Check to Store name with Store Street, Store Town, Store State, Store Postcode, Store Country.</p>
                                                    </div>

                                                    <div class="single-method">
                                                        <input type="radio" id="payment_cash" disabled name="payment-method" value="cash">
                                                        <label for="payment_cash">Taksit kartlar</label>
                                                        <p data-method="cash">Please send a Check to Store name with Store Street, Store Town, Store State, Store Postcode, Store Country.</p>
                                                    </div>

                                                </div>

                                                <button class="place-order">RƏSMİLƏŞDİR</button>

                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                    <!--=======  End of page wrapper  =======-->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/front/checkout.blade.php ENDPATH**/ ?>