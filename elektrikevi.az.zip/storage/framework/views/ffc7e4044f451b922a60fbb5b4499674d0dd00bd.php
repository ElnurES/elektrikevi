
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('front.layouts.include.header-two',['desktopCategory'=>$desktopCategory,'mobileCategory'=>$mobileCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('front.layouts.include.breadcrumb',compact('crumbs','title'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="page-content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!--=======  page wrapper  =======-->
                    <div class="page-wrapper">
                        <div class="page-content-wrapper">
                            <?php echo $__env->make('front.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php if(is_array($wishlistProducts) and count($wishlistProducts)>0): ?>
                                <form action="#">
                                    <!--=======  cart table  =======-->
                                    <div class="cart-table table-responsive">
                                        <table class="table">
                                            <thead>
                                            <tr>
                                                <th class="pro-thumbnail"></th>
                                                <th class="pro-title">Ad</th>
                                                <th class="pro-price">Qİymət</th>
                                                <th class="pro-remove">Sİl</th>
                                                <th class="pro-title">Səbət</th>
                                            </tr>
                                            </thead>
                                            <tbody class="cartTable">
                                            <?php $__currentLoopData = $wishlistProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="pro-thumbnail">
                                                        <a href="<?php echo e(route('product.detail',$wishlist['slug'])); ?>">
                                                            <img src="<?php echo e(asset("uploads/product").'/'.$wishlist['photo']); ?>" class="img-fluid" alt="<?php echo e($wishlist['name']); ?>">
                                                        </a>
                                                    </td>
                                                    <td class="pro-title"><a class="locationChoose" href="<?php echo e(route('product.detail',$wishlist['slug'])); ?>"><?php echo e($wishlist['name']); ?></a></td>
                                                    <td class="pro-price"><span>$<?php echo e($wishlist['price']); ?></span></td>
                                                    <td class="pro-remove"><a href="<?php echo e(route('removeFromWishlistById',$wishlist['id'])); ?>"><i class="fa fa-trash-o"></i></a></td>
                                                    <td>
                                                        <?php if(in_array($wishlist['id'],$basketItem)): ?>
                                                            <a href="<?php echo e(route('removeFromCartById',$wishlist['id'])); ?>">
                                                                <i class="ion-minus fa-2x"></i>
                                                            </a>
                                                        <?php else: ?>
                                                            <a href="<?php echo e(route('addToCartById',$wishlist['id'])); ?>">
                                                                <i class="ion-plus fa-2x"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--=======  End of cart table  =======-->
                                </form>
                            <?php else: ?>
                                <div class="alert alert-info" role="alert">
                                    Seçilmiş məhsul yoxdur!
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!--=======  End of page wrapper  =======-->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/front/wishlist.blade.php ENDPATH**/ ?>