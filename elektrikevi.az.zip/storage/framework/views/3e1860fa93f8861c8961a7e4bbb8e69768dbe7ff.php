
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('page-header'); ?>
    <?php echo $__env->make('back.layouts.include.page-header',compact('crumbs'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('back.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="panel panel-flat">
        <div class="panel-heading">
            <h5 class="panel-title"><?php echo e($title); ?></h5>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Email</th>
                    <th>Abunəlik Tarixi</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php if($subscribes->count()>0): ?>
                    <?php $__currentLoopData = $subscribes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$subscribe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><a href="mailto:<?php echo e($subscribe->email); ?>"><?php echo e($subscribe->email); ?></a></td>
                            <td><?php echo e($subscribe->subscribe_created_at()); ?></td>
                            <td>
                                <a href="mailto:<?php echo e($subscribe->email); ?>" class="label label-info"><i class="fa fa-pencil"></i> Cavab Yaz </a>
                                <a style="color:red;" onclick='checkDeleteConfrim("<?php echo e(route('admin.subscribe.destroy',$subscribe->id)); ?>")'> <i class="fa fa-trash"></i> Sil</a>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
    <script>
        function checkDeleteConfrim(url) {
            swal({
                title: "Silmək istədiynizdən əminsizmi?",
                text: "Silinəndən sonra bu əməliyyatı bərpa edə bilməyəcəksiniz!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
                .then((willDelete) => {
                    if (willDelete) {
                        location.href = url;
                    } else {
                        swal("Heç bir əməliyyat aparılmadı");
                    }
                });


        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/back/subscribe.blade.php ENDPATH**/ ?>