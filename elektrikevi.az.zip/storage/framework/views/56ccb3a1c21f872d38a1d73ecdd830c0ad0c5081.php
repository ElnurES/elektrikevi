<div class="page-header">

    <div class="breadcrumb-line breadcrumb-line-component mt-20 mb-20">
        <ul class="breadcrumb">
            <li><a href="<?php echo e(route('admin')); ?>"><i class="icon-home2 position-left"></i> Əsas Səhifə</a></li>
            <?php if(count($crumbs)>0): ?>
                <?php $__currentLoopData = $crumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$crumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$loop->last): ?>
                        <li><a href="<?php echo e($crumb); ?>"><?php echo e($key); ?></a></li>
                    <?php else: ?>
                        <li class="active"><?php echo e($key); ?></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>

    </div>
</div><?php /**PATH C:\Users\HP\Desktop\kabel\resources\views/back/layouts/include/page-header.blade.php ENDPATH**/ ?>