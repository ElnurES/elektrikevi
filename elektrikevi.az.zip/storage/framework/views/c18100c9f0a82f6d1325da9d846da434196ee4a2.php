<?php
    $title='Səhifə tapılmadı';
        $crumbs=[
            'Səhifə tapılmadı'=>null
        ];
        $desktopCategory=view('front.layouts.include.header-one')->render();
        $mobileCategory=view('front.layouts.include.header-one-mobile')->render();
?>

<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('front.layouts.include.header-two',['desktopCategory'=>$desktopCategory,'mobileCategory'=>$mobileCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('front.layouts.include.breadcrumb',compact('crumbs','title'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="container">
        <div class="jumbotron text-center">
            <h1>404</h1>
            <h3>Səhifə tapılmadı</h3>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Əsas Səhifə</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\elektrikevi.az\resources\views/errors/404.blade.php ENDPATH**/ ?>