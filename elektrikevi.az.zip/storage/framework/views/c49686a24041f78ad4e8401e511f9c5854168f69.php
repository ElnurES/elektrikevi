<?php $__env->startSection('title','Əsas Səhifə'); ?>
<?php $__env->startSection('page-header'); ?>
    <?php echo $__env->make('back.layouts.include.page-header',compact('crumbs'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="row text-center placeholders">
        <div class="col-6 col-sm-3">
            <div class="panel panel-primary">
                <div class="panel-heading">Məhsullar</div>
                <div class="panel-body">
                    <h4><?php echo e($products->count()); ?></h4>
                    <a href="<?php echo e(route('admin.product')); ?>">Daha Çox</a>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-3">
            <div class="panel panel-primary">
                <div class="panel-heading">Mesajlar</div>
                <div class="panel-body">
                    <h4><?php echo e($contacts->count()); ?></h4>
                    <a href="<?php echo e(route('admin.contact')); ?>">Daha Çox</a>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-3">
            <div class="panel panel-primary">
                <div class="panel-heading">Abunələr</div>
                <div class="panel-body">
                    <h4><?php echo e($subscribes->count()); ?></h4>
                    <a href="<?php echo e(route('admin.subscribe')); ?>">Daha Çox</a>
                </div>
            </div>
        </div>
        <div class="col-6 col-sm-3">
            <div class="panel panel-primary">
                <div class="panel-heading">İstifadəçilər</div>
                <div class="panel-body">
                    <h4><?php echo e($users->count()); ?></h4>
                    <a href="<?php echo e(route('admin.user')); ?>">Daha Çox</a>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-12">
            <div class="panel panel-primary">
                <div class="panel-heading">Sifarişlər</div>
                <div class="panel-body">
                    <h4><?php echo e($orders->count()); ?></h4>
                    <a href="<?php echo e(route('admin.order')); ?>">Daha Çox</a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\kabel\resources\views/back/index.blade.php ENDPATH**/ ?>