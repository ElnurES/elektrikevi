<?php if(count($errors)>0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger msj" role="alert" style="background: lightcoral">
            <?php echo e($error); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<?php if(session()->has('mesaj')): ?>
    <div class="alert alert-<?php echo e(session('type')); ?> msj" role="alert">
        <?php echo e(session('mesaj')); ?>

    </div>
<?php endif; ?>


<?php if(session()->has('swal')): ?>
    <?php
        $icon='';
        if(session('type')=='success') {
            $icon='Ok!';
        }

        if(session('type')=='warning') {
            $icon='Ups!';
        }

        if(session('type')=='info') {
            $icon='!';
        }
    ?>
    <script>
        swal("<?php echo e($icon); ?>", "<?php echo e(session('swal')); ?>", "<?php echo e(session('type')); ?>");
    </script>
<?php endif; ?><?php /**PATH C:\Users\HP\Desktop\elektrikevi.az\resources\views/front/layouts/include/alert-messages.blade.php ENDPATH**/ ?>