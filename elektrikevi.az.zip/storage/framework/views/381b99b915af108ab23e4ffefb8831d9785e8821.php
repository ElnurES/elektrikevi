<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('front.layouts.include.header-two',['desktopCategory'=>$desktopCategory,'mobileCategory'=>$mobileCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('front.layouts.include.breadcrumb',compact('crumbs','title'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="page-content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!--=======  page wrapper  =======-->
                    <div class="page-wrapper">
                        <div class="page-content-wrapper">
                            <div class="row">

                                <div class="col-lg-12">
                                    <div class="about-top-content-wrapper">
                                        <div class="row row-30">
                                            <!-- About Image -->
                                            <div class="col-lg-6">
                                                <div class="about-image">
                                                    <img src="/front/assets/img/banners/img2-middle-eposi1.jpg" class="img-fluid" alt="">
                                                </div>
                                            </div>

                                            <!-- About Content -->
                                            <div class="about-content col-lg-6">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <h1>WELCOME TO <span>Eposi.</span></h1>
                                                        <p class="mb-3">Eposi provide how all this mistaken idea of denouncing pleasure and sing pain was born an will give you a complete account of the system, and expound the actual teachings of the eat explorer of the truth, the mer of human.</p>
                                                    </div>

                                                    <div class="col-12">
                                                        <h4>WIN BEST ONLINE SHOP AT 2019</h4>
                                                        <p>Eposi provide how all this mistaken idea of denouncing pleasure and sing pain was born an will give you a complete account of the system, and expound the actual teachings of the eat explorer of the truth, the mer of human.</p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>


                        </div>
                    </div>
                    <!--=======  End of page wrapper  =======-->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\kabel\resources\views/front/about.blade.php ENDPATH**/ ?>