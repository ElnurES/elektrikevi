
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('head'); ?>

    <!-- Theme JS files -->
    <script type="text/javascript" src="/back/assets/js/plugins/tables/datatables/datatables.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/plugins/tables/datatables/extensions/responsive.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/plugins/forms/selects/select2.min.js"></script>
    <script type="text/javascript" src="/back/assets/js/pages/datatables_responsive.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <?php echo $__env->make('back.layouts.include.page-header',compact('crumbs'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('back.layouts.include.alert-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="panel panel-flat">
        <div class="panel-heading">
            <h5 class="panel-title"><?php echo e($title); ?></h5>
            <div class="heading-elements">
                <a href="<?php echo e(route('admin.category.create')); ?>"><span class="label label-success">YENİ KATEQORİYA</span></a>
            </div>
        </div>

        <table class="table datatable-responsive-row-control">
            <thead>
            <tr>
                <th></th>
                <th>Şəkil</th>
                <th>Üst Kateqoriya</th>
                <th>Ad</th>
                <th>Slug</th>
                <th>Domain</th>
                <th>Yenilənmə Tarixi</th>
                <th class="text-center">Düzəlişlər</th>
            </tr>
            </thead>
            <tbody>
            <?php if($categorys->count()>0): ?>
                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td>
                            <a href="<?php echo e(route('admin.category.show.product',$category->slug)); ?>">
                                <img style="width: 50px;" src="<?php echo e(asset("uploads/catalog").'/'.$category->photo); ?>"  alt="">
                            </a>
                        </td>
                        <td><a href="<?php echo e(route('admin.category.show.product',$category->slug)); ?>"><?php echo e($category->parentWithDefault->name); ?></a></td>
                        <td><a href="<?php echo e(route('admin.category.show.product',$category->slug)); ?>"><?php echo e($category->name); ?></a></td>
                        <td><a href="<?php echo e(route('admin.category.show.product',$category->slug)); ?>"><?php echo e($category->slug); ?></a></td>
                        <td><span class="label label-success"><?php echo e($category->categoryDomain->name); ?></span></td>
                        <td><?php echo e($category->category_updated_at_no_pm()); ?></td>
                        <td class="text-center">
                            <ul class="icons-list">
                                <li class="dropdown">
                                    <a class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="icon-menu9"></i>
                                    </a>

                                    <ul class="dropdown-menu dropdown-menu-right">
                                        <li><a href="<?php echo e(route('admin.category.edit',$category->slug)); ?>"><i class="icon-database-edit2"></i> Yenilə</a></li>
                                        <li><a href="<?php echo e(route('admin.category.show.product',$category->slug)); ?>"><i class="icon-eye"></i> Məhsulları</a></li>
                                        <li><a  onclick='checkDeleteConfrim("<?php echo e(route('admin.category.destroy',$category->slug)); ?>","<?php echo e(count($category->child)); ?>")'><i class="icon-database-remove"></i> Sil</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </td>
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
    <script>
        function checkDeleteConfrim(url,parentId) {
            if(parentId==0) {
                swal({
                    title: "Silmək istədiynizdən əminsizmi?",
                    text: "Silinəndən sonra bu əməliyyatı bərpa edə bilməyəcəksiniz!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                    .then((willDelete) => {
                        if (willDelete) {
                            location.href = url;
                        } else {
                            swal("Heç bir əməliyyat aparılmadı");
                        }
                    });
            } else {
                swal({
                title: "Üst kateqoriya silinə bilməz!",
                    text: "İlk öncə bu kateqoriyanın alt kateqoriyalarını silməlisiniz!.",
                    icon: "warning",
                    button: "Ok",
                });
            }


        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demosayt/domains/elektrikevi.az/public_html/resources/views/back/category/index.blade.php ENDPATH**/ ?>